/// <reference types="./types" />
declare class DiagramEditor {
    editUrl: string;
    initial: string;
    name: string;
    vditor: IVditor;
    constructor(vditor: IVditor);
    edit(elt: any): void;
    new(): void;
    load(): void;
    start(): void;
}
export { DiagramEditor };
