/// <reference types="./types" />
export declare const highlightToolbarIR: (vditor: IVditor) => void;
