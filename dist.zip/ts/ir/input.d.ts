/// <reference types="./types" />
export declare const input: (vditor: IVditor, range: Range, ignoreSpace?: boolean, event?: InputEvent) => void;
