export declare const abcRender: (element?: (HTMLElement | Document), cdn?: string) => void;
