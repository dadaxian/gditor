export declare const chartRender: (element: (HTMLElement | Document), cdn: string, theme: string) => void;
