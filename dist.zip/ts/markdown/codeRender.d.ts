export declare const codeRender: (element: HTMLElement) => void;
