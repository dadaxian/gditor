/// <reference types="./types" />
export declare const getMarkdown: (vditor: IVditor) => string;
