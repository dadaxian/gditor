export declare const mindmapRender: (element: (HTMLElement | Document), cdn: string, theme: string) => void;
