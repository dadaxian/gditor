export declare const plantumlRender: (element?: (HTMLElement | Document), cdn?: string) => void;
