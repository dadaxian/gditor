/// <reference types="./types" />
export declare const inputEvent: (vditor: IVditor, event?: InputEvent) => void;
