export declare class Tip {
    element: HTMLElement;
    constructor();
    show(text: string, time?: number): void;
    hide(): void;
}
