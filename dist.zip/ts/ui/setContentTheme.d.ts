export declare const setContentTheme: (contentTheme: string, path: string) => void;
