/// <reference types="./types" />
declare class Upload {
    element: HTMLElement;
    isUploading: boolean;
    range: Range;
    constructor();
}
/**
 * 上传新增画图
 * @param vditor
 * @param files
 * @param element
 * @returns
 */
declare const uploadFilesWithNew: (vditor: IVditor, files: FileList | DataTransferItemList | File[]) => Promise<void>;
/**
 * 覆盖原来的文件
 * @param vditor
 * @param files
 * @param element
 * @param nameFix
 * @returns
 */
declare const uploadFilesWithCover: (vditor: IVditor, files: FileList | DataTransferItemList | File[], elt: any) => Promise<void>;
declare const uploadFiles: (vditor: IVditor, files: FileList | DataTransferItemList | File[], element?: HTMLInputElement) => Promise<void>;
export { Upload, uploadFiles, uploadFilesWithCover, uploadFilesWithNew };
