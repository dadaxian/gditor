/// <reference types="./types" />
export declare class ContentData implements IContentData {
    title: string;
    createTime?: string;
    changeTileFun: Function;
    constructor();
}
