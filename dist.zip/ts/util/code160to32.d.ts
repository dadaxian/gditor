export declare const code160to32: (text: string) => string;
