export declare const hasClosestByTag: (element: Node, nodeName: string) => false | HTMLElement;
export declare const hasClosestByHeadings: (element: Node) => false | HTMLElement;
