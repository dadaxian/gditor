export declare const matchHotKey: (hotKey: string, event: KeyboardEvent) => boolean;
