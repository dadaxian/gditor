/// <reference types="./types" />
declare class WYSIWYG {
    range: Range;
    titleTextArea: HTMLTextAreaElement;
    element: HTMLPreElement;
    popover: HTMLDivElement;
    selectPopover: HTMLDivElement;
    afterRenderTimeoutId: number;
    hlToolbarTimeoutId: number;
    preventInput: boolean;
    composingLock: boolean;
    commentIds: string[];
    private scrollListener;
    constructor(vditor: IVditor);
    autoTextarea(elem: any, minHeight: any, vditor: IVditor, extra?: any, maxHeight?: any): void;
    autoVditorTitle(vditor: IVditor, titleTextArea: HTMLTextAreaElement): void;
    getComments(vditor: IVditor, getData?: boolean): ICommentsData[];
    triggerRemoveComment(vditor: IVditor): void;
    showComment(): void;
    hideComment(): void;
    unbindListener(): void;
    private copy;
    private bindEvent;
}
export { WYSIWYG };
