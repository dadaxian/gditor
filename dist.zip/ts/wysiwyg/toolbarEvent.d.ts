/// <reference types="./types" />
export declare const toolbarEvent: (vditor: IVditor, actionBtn: Element, event: Event) => void;
